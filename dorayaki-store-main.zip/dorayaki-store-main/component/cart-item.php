<tr>
    <td class="item-start thumbnail-wrapper">
        <img class="thumbnail" src="img/sample.jpg">
    </td>
    <td class="item-title">Dorayaki Rasa Teriyaki</td>
    <td class="item-desc">12</td>
    <td class="item-desc">Rp 12.000,00</td>
    <td class="item-end item-desc">Rp 12.000,00</td>
</tr>