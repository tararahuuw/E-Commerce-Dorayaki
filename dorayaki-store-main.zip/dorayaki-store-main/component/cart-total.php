<div class="flex-container row justify-end">
    <div class="flex-container column mr-1">
        <h3 class="justify-end">Total</h3>
        <h1>Harro, I Raiku Ramen</h2>
    </div>
    
    <button class="btn-primary flex-container row">
        Beli Dorayaki 
        <img src="img/chevron-right.svg"/>
    </button>
</div>
