<div class="search-card flex-container column">
    <div class="card-img">
        <img class="card-cover" src="img/sample.jpg">
    </div>
    <div class="card-details flex-container column">
        <h3 class="card-title">Dorayaki Rasa Teriyaki</h3>
        <div class="card-stats flex-container row">
            <div class="flex-container column mr-3">
                <h6 class="desc-title">TERJUAL</h6>
                <h4 class="desc-content">123</h4>
            </div>
            <div class="flex-container column">
                <h6 class="desc-title">STOK</h6>
                <h4 class="desc-content">1292</h4>
            </div>
        </div>
        <div class="desc-container">
            <p class="card-desc">Some long text here uywawa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>
        </div>
    </div>
    <div class="card-button item-end">
        <button class="btn-primary">Edit</button>
    </div>
</div>