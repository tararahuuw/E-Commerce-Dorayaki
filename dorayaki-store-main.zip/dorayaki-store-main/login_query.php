<?php
	//starting the session
	session_start();
	//including the database connection
	require_once 'conn.php';

    if (isset($_SESSION["login"])) {
		header("Location: home.php");
		exit; 
    }

	if(ISSET($_POST['login'])){
		// Setting variables
		$username = $_POST['username'];
		$password = $_POST['password'];

		// Select Query for counting the row that has the same value of the given username and password. This query is for checking if the access is valid or not.
		$pdo = new PDO('sqlite:db/db_member.sqlite3');

        $statement = $pdo->query("SELECT * FROM member");
    
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement = $pdo->query("SELECT * FROM member where username == '$username'");
    
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
		if($rows && password_verify($password, $rows[0]['password'])){
			setcookie('id', $rows[0]['mem_id'], time()+3600);
			setcookie('username', $rows[0]['username'], time()+3600);
			setcookie('is_admin', $rows[0]['is_admin'], time()+3600);

			header('location:home.php');
		}
		else{
			$_SESSION['error'] = "Invalid username or password";
			header('location:index.php');
		}
	}
?>