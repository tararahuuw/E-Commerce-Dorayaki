<!DOCTYPE html>

<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }

    if (!isset($_SESSION["login"])) {
        header("Location: logout.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    $username = $_COOKIE["username"];

    $pdo = new PDO('sqlite:db/db_member.sqlite3');
    $index = (int)$_GET["id"];
    $product = $pdo->query("SELECT * FROM variant where var_id == $index");
    $product = $product->fetchAll(PDO::FETCH_ASSOC);
    if (!$product) {
        $_SESSION['error'] = 404;
        header('location: error_page.php');
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="css/variant.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <title><?php echo($product[0]["nama"])  ?></title>
    <link rel="icon" href="img/<?php echo($product[0]['gambar'])  ?>" type="image/icon type">
</head>
<body>
    <!-- Component navbar -->
    <?php include 'component/navbar.php'; ?>

    <!-- Session modal -->
    <div class="pop-up">
        <?php
        if (isset($_SESSION['variant_updated']) && $_SESSION['variant_updated'] == true) { ?>
            <h2 id="pesan" class="sukses"> <?php echo $_SESSION['pesan'] ?> </h2>
            <?php
            unset($_SESSION['variant_updated']);
            unset($_SESSION['pesan']);
        } else if (isset($_SESSION['pesan'])){ ?>
            <h2 id="pesan" class="gagal"> <?php echo $_SESSION['pesan'] ?> </h2>
            <?php 
            unset($_SESSION['pesan']);
        } ?>
    </div>
    <div id="popup" class="popup hilang">
        <h2 class="pesan">Apakah anda yakin ingin menghapus varian <?php echo $product[0]['nama'] ?>?</h2>
        <a class="button-card" id="close">Tidak</a>     
        <a class="button-card  delete-button" href="script/delete_variant_from_db.php?id=<?= $product[0]['var_id']; ?>">Hapus</a>     
    </div>

    <!-- Product detail -->
    <div class = "container-productdetail">
        <div class ="card">
            <img src="img/<?php echo($product[0]['gambar'])  ?>"/>
            <p class="judul-card"><?php echo($product[0]["nama"])  ?></p>
            <p class="deskripsi-card"><?php echo($product[0]["deskripsi"])  ?></p>
            <p class="terjual-card">Jumlah terjual : <?php echo($product[0]["terjual"])  ?></p>
            <p class="terjual-card">Harga : <?php echo($product[0]["harga"])  ?></p>
            <p class="terjual-card">Stok : <?php echo($product[0]["stok"])  ?></p>
            <?php 
            if ($is_admin === "Customer") { ?>
                <a class="button-card" href="beli_variant.php?id=<?= $product[0]['var_id']; ?>">Beli</a>
            <?php
            } else { ?>
                <a class="button-card" href="update_variant.php">Ubah Stok</a>
                <a class="button-card" href="edit_variant.php?id=<?= $product[0]['var_id']; ?>">Edit</a>
                <a class="button-card delete-button" onclick="popup()">Delete</a>
            <?php
            } ?>
        </div>
    </div>

    <script src="js/navbar.js"></script>
    <script>
        // Delete Variant popup
        var pop = 0;
        var popup = function() {
            if (pop == 0){
                document.getElementById('popup').className = "popup";
                document.getElementById('close').onclick = function(){close()};
                pop = 1;
            } else {
                close();
            }
        };
        // Close popup
        function close() {
            document.getElementById('popup').className="popup hilang";
            pop = 0;
        };
        setTimeout(function(){
            document.getElementById('pesan').className += ' hilang';
        }, 2000);
    </script>
</body>
</html>