<!DOCTYPE html>

<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }

    if (!isset($_SESSION["login"])) {
        header("Location: logout.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    $username = $_COOKIE["username"];

/*     $pdo = new PDO('sqlite:db/db_member.sqlite3');
    $index = (int)$_GET["id"];
    $product = $pdo->query("SELECT * FROM variant where var_id == $index");
    $product = $product->fetchAll(PDO::FETCH_ASSOC); */

?>

<?php include 'script/get_variance_service.php'; ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="css/variant.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <title>Update Variance Stock</title>
    <link rel="icon" href="img/<?php echo($product[0]['gambar'])  ?>" type="image/icon type">
</head>
<body>

    <!-- Component Navbar -->
    <?php include 'component/navbar.php'; ?>
    <div id="popup"></div>

    <!-- Card product -->
    <div class = "container-productdetail">
        <div class ="card">
        <form id="submit-form" method="POST" enctype="multipart/form-data" action="script/update_variance_service.php">
            <div class="form">
                <div class="m-05 flex-container column">
                <h5>Nama Varian: </h5>
                <select class="input" name="varian">
                    <?php for ($i=0; $i < count($listDorayaki); $i++) {?>    
                        <option value="<?php echo $listDorayaki[$i]["recipeName"]?>">
                            <?php echo $listDorayaki[$i]["recipeName"]?>
                        </option>
                    <?php } ?> 
                </select>
                </div>
                <div class="m-05 flex-container column">
                    <input type="hidden" name="var_id" value="<?php echo $product[0]['var_id'] ?>"/>
                    <h5>Tambah Stok: </h5>
                    <input type="number" name="stok" placeholder="Stok" class="input" value="<?php echo $product[0]['stok'] ?>"/><br>
                </div>
            </div>
            <input type="submit" name="submit" value="Ubah" class="submit p-2"/>
        </form>
        
         
        </div>
    </div>
    <div id="max-stock" style="display: none"><?php echo($product[0]['stok']) ?></div>
    <div id="price-stock" style="display: none"><?php echo($product[0]['harga']) ?></div>
    <script src="js/navbar.js"></script>
    <script src="js/pembelian.js"></script>
  <!--   <script>
        setTimeout(function(){
            document.getElementById('pesan').className += ' hilang';
        }, 2000);
        </script> -->
</body>
</html>
