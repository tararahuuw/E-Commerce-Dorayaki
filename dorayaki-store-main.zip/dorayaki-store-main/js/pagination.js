function load_data(query = '', page_number = 1)
{
	var form_data = new FormData();

	form_data.append('query', query);
	form_data.append('page', page_number);

	var ajax_request = new XMLHttpRequest();

	ajax_request.open('POST', 'pagination.php');

	ajax_request.send(form_data);

	ajax_request.onreadystatechange = function()
	{
		if(ajax_request.readyState == 4 && ajax_request.status == 200)
		{
			var response = JSON.parse(ajax_request.responseText);

			var html = '';

			var variant = response.data;

			if(response.total_data > 0)
			{
                for(var i = 0; i < variant.length; i++)
				{
					html += '<a href="detailproduct.php?id='+variant[i].var_id+'">';
					html += '   <div class ="card">';
					html += '       <img src="img/'+variant[i].gambar+'"/>';
					html += '       <p class="judul-card">'+variant[i].nama+'</p>';
					html += '       <p class="deskripsi-card">'+variant[i].deskripsi+'</p>';
					html += '       <p class="terjual-card">Jumlah terjual : '+variant[i].terjual+'</p>';
					html += '   </div>';
					html += '</a>';
				}
			}
			else
			{
				html += '<h1>No Data Found</h1>';
			}

			document.getElementById('post_data').innerHTML = html;
            
            document.getElementById('pagination').innerHTML = response.pagination;
		}

	}
}