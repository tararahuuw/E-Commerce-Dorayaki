git <?php
	//check if the database file exists and create a new if not
	if(!is_file('db/db_member.sqlite3')){
		file_put_contents('db/db_member.sqlite3', null);
	}
	// connecting the database
	$conn = new PDO('sqlite:db/db_member.sqlite3');
	//Setting connection attributes
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	//Query for creating reating the member table in the database if not exist yet.
	$query = "CREATE TABLE IF NOT EXISTS variant(var_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nama TEXT, deskripsi TEXT, harga INTEGER, stok INTEGER, gambar BLOB)";
	//Executing the query
	$conn->exec($query);
?>