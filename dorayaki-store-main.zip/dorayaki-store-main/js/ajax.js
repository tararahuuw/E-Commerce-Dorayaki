// ambil elemen2 yang dibutuhkan
var username = document.getElementById('username');
var container = document.getElementById('registercontainer');

// tambahkan event ketika keyword ditulis
username.addEventListener('keyup', function() {

    // buat object ajax
    var xhr = new XMLHttpRequest();

    // cek kesiapan ajax
    xhr.onreadystatechange = function() {
        if( xhr.readyState == 4 && xhr.status == 200 ) {
            container.innerHTML = xhr.responseText;
            // border.style.borderColor = "salmon"
            // console.log(username.value);
        }
    }

    // eksekusi ajax
    xhr.open('GET', 'save_member.php?username='+username.value, true);
    xhr.send();

});