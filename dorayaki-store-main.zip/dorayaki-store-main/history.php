<!DOCTYPE html>
<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }

    if (!isset($_SESSION["login"])) {
        header("Location: logout.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    $username = $_COOKIE["username"];

    //Processing select database

    $pdo = new PDO('sqlite:db/db_member.sqlite3');

    $statement = $pdo->query("SELECT * FROM pembelian ORDER BY date DESC");
    $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

    $row_count= $pdo->query("SELECT COUNT(*) as count FROM pembelian ORDER BY date DESC");
    $row_count = $row_count->fetchAll(PDO::FETCH_ASSOC);
    $row_count = ((int)$row_count[0]['count']);

    $statement = $pdo->query("SELECT * FROM pembelian where username == '$username' ORDER BY date DESC");
    $rows_customer = $statement->fetchAll(PDO::FETCH_ASSOC);

    $row_count_customer= $pdo->query("SELECT COUNT(*) as count FROM pembelian where username == '$username' ORDER BY date DESC");
    $row_count_customer = $row_count_customer->fetchAll(PDO::FETCH_ASSOC);
    $row_count_customer = ((int)$row_count_customer[0]['count']);

    $statement2 = $pdo->query("SELECT * FROM stok_history ORDER BY date DESC");
    $rows2 = $statement2->fetchAll(PDO::FETCH_ASSOC);

    $row2_count= $pdo->query("SELECT COUNT(*) as count FROM stok_history ORDER BY date DESC");
    $row2_count = $row2_count->fetchAll(PDO::FETCH_ASSOC);
    $row2_count = ((int)$row2_count[0]['count']);
?>
<html lang="en">
	<head>
        <title>Dorayaki Store</title>
        <link rel="stylesheet" type="text/css" href="css/dashboard.css">
        <link rel="stylesheet" type="text/css" href="css/history.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
<body>

    <!-- Component Navbar -->
    <?php include 'component/navbar.php'; ?>
      <div class="table-container">
        <!-- Table of history -->
        <p class="riwayat_pembelian">Riwayat Pembelian</p>
        <table id="customers">
            <?php 
                if ($is_admin === "Customer") { ?>
                    <tr>
                        <th>No</th>
                        <th>Varian</th>
                        <th>Jumlah</th>
                        <th>Harga</th>
                        <th>Waktu Pembelian</th>
                    </tr>
                    <?php
                        for ($i=0; $i<$row_count_customer; $i++){
                            $count = $i + 1;
                            $varian = $rows_customer[$i]['varian'];
                            $jumlah = $rows_customer[$i]['jumlah'];
                            $harga = $rows_customer[$i]['harga'];
                            $date = $rows_customer[$i]['date'];
                            echo("<tr>
                                <td>$count</td>
                                <td><a href=\"detailproduct.php?id=".$rows_customer[$i]['var_id']."\">$varian</a></td>
                                <td>$jumlah</td>
                                <td>$harga</td>
                                <td>$date</td>
                            </tr>");
                        }
                    }
                else { ?>
                
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Varian</th>
                        <th>Jumlah</th>
                        <th>Harga</th>
                        <th>Waktu Pembelian</th>
                    </tr>
                    <?php
                        for ($i=0; $i<$row_count; $i++){
                            $count = $i + 1;
                            $username = $rows[$i]['username'];
                            $varian = $rows[$i]['varian'];
                            $jumlah = $rows[$i]['jumlah'];
                            $harga = $rows[$i]['harga'];
                            $date = $rows[$i]['date'];
                            echo("<tr>
                                <td>$count</td>
                                <td>$username</td>
                                <td><a href=\"detailproduct.php?id=".$rows[$i]['var_id']."\">$varian</a></td>
                                <td>$jumlah</td>
                                <td>$harga</td>
                                <td>$date</td>
                            </tr>");
                        }?>
                        </table><br><br> <?php
                    if ($row2_count > 0) { ?>
                        <div class="riwayat_pengubahan">

                            <p class="riwayat_pembelian">Riwayat Pengubahan Stok</p>
                            <table id="customers">
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Varian</th>
                                <th>Stok Awal</th>
                                <th>Stok Akhir</th>
                                <th>Pengubahan</th>
                                <th>Waktu Pembelian</th>
                            </tr>
                            <?php
                        for ($i=0; $i<$row2_count; $i++){
                            $count = $i + 1;
                            $username2 = $rows2[$i]['username'];
                            $varian2 = $rows2[$i]['varian'];
                            $stok_awal = $rows2[$i]['stok_awal'];
                            $stok_akhir = $rows2[$i]['stok_akhir'];
                            $pengubahan = $rows2[$i]['pengubahan'];
                            $date2 = $rows2[$i]['date'];
                            echo("<tr>
                            <td>$count</td>
                            <td>$username2</td>
                            <td><a href=\"detailproduct.php?id=".$rows2[$i]['var_id']."\">$varian2</a></td>
                            <td>$stok_awal</td>
                            <td>$stok_akhir</td>
                            <td>$pengubahan</td>
                            <td>$date2</td>
                            </tr>
                            </div>");
                        }
                    }
                }
                ?>
            </table>
        </div>
    <script src="js/navbar.js"></script>
</body>
</html>