<?php
    session_start();
    // remove all session variables
    session_unset();

    setcookie('id', '', time() - 3600);
    setcookie('key', '', time() - 3600);
    setcookie('username', '', time() - 3600);
    setcookie('key', '', time() - 3600);
    setcookie('is_admin', '', time() - 3600);
    setcookie('key', '', time() - 3600);

    // destroy the session
    session_destroy();
    header("Location: index.php");
?>
