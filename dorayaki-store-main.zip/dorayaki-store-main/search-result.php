<!DOCTYPE html>
<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }

    if (!isset($_SESSION["login"])) {
        header("Location: logout.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    $username = $_COOKIE["username"];
    $search_query = $_POST["search-query"];
    $pdo = new PDO('sqlite:db/db_member.sqlite3');

    // pagination
    // konfigurasi
    $jumlahDataPerHalaman = 10;
    $jumlahData= $pdo->query("SELECT COUNT(*) as count FROM variant WHERE nama LIKE '%$search_query%'");
    $jumlahData = $jumlahData->fetchAll(PDO::FETCH_ASSOC);
    $jumlahHalaman = ceil((int)$jumlahData[0]["count"] / $jumlahDataPerHalaman);
    $halamanAktif = ( isset($_GET["halaman"]) ) ? $_GET["halaman"] : 1;
    $awalData = ( $jumlahDataPerHalaman * $halamanAktif ) - $jumlahDataPerHalaman;

    $variant= $pdo->query("SELECT * FROM variant WHERE nama LIKE '%$search_query%' ORDER BY terjual DESC LIMIT $awalData, $jumlahDataPerHalaman");
    $variant = $variant->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="en">
	<head>
        <title>Dorayaki Store</title>
        <link rel="stylesheet" type="text/css" href="css/dashboard.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
<body>
    <!-- Navbar component -->
    <?php include 'component/navbar.php'; ?>
        <!-- Card search result -->
        <div class = "container-content">
        <?php 
                for ($i=0; $i<count($variant); $i++) {?>
                    <a href="detailproduct.php?id=<?= $variant[$i]['var_id']; ?>">
                        <div class ="card">
                            <div class="card-img">
                                <img class="card-cover" src="img/<?php echo($variant[$i]['gambar'])  ?>">
                            </div>
                            <p class="judul-card"><?php echo($variant[$i]["nama"])  ?></p>
                            <div class="desc-container">
                                <p class="card-desc"><?php echo($variant[$i]["deskripsi"])  ?></p>
                            </div>
                            <p class="terjual-card">Jumlah terjual : <?php echo($variant[$i]["terjual"])  ?></p>
                        </div>
                    </a>
                <?php }
            ?>
        </div>

        <!-- Pagination -->
        <div class = "pagination">
            <?php if( $halamanAktif > 1 ) : ?>
                <a href="?halaman=<?= $halamanAktif - 1; ?>">&laquo;</a>
            <?php endif; ?>
    
            <?php for( $i = 1; $i <= $jumlahHalaman; $i++ ) : ?>
                <?php if( $i == $halamanAktif ) : ?>
                    <a href="?halaman=<?= $i; ?>" class="halaman-aktif"><?= $i; ?></a>
                <?php else : ?>
                    <a class="halaman-nonaktif" href="?halaman=<?= $i; ?>"><?= $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>
    
            <?php if( $halamanAktif < $jumlahHalaman ) : ?>
                <a href="?halaman=<?= $halamanAktif + 1; ?>">&raquo;</a>
            <?php endif; ?>
        </div>
        
    <script src="js/navbar.js"></script>
    <script src="js/pagination.js"></script>
</body>
</html>