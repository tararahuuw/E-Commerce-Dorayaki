<?php
	//starting the session
	session_start();

	$pdo = new PDO('sqlite:../db/db_member.sqlite3');
    $var_id = (int)$_GET["id"];

	$statement = $pdo->query("SELECT * FROM variant");

	$rows = $statement->fetchAll(PDO::FETCH_ASSOC);
	$statement = $pdo->query("SELECT * FROM variant where var_id == '$var_id'");

	$rows = $statement->fetchAll(PDO::FETCH_ASSOC);
	$nama = $rows[0]['nama'];

	// Insertion Query
	$query = "DELETE FROM `variant` WHERE var_id == :var_id";
	$stmt = $pdo->prepare($query);
	$stmt->bindParam(':var_id', $var_id);

	// Check if the execution of query is success
	if(strlen($syntaxErr)>0) {
		$_SESSION['pesan'] = "Varian gagal dihapus";
		header('location: ../detailproduct.php?id='.$var_id);
	}
	else {
		if($stmt->execute()){
			//setting a 'success' session to save our insertion success message.
			$_SESSION['variant_deleted'] = true;
			$_SESSION['pesan'] = "Varian $nama berhasil dihapus";

			//redirecting to the index.php 
			header('location: ../home.php');
		}
	}
?> 
