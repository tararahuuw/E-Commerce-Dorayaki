<?php
    session_start();
    $wsdl   = "http://localhost:9999/webservice/dorayaki?wsdl";
    $client = new SoapClient($wsdl, array('trace'=>1));  // The trace param will show you errors stack
    
    $id = $_POST['var_id'];
    $name = $_POST['varian'];
    $quantity = $_POST['stok'];

    $request_param = array(
        "addStock" => array(
            "arg0"    => $quantity,
            "arg1"    => $name            
        ) 
    );
    
    try
    {
        // $responce_param = $client->webservice_methode_name($request_param);
       $listDorayaki =  $client->__soapCall("addStock", $request_param)->return; // Alternative way to call soap method
    //    $listDorayaki = json_decode($listDorayaki, true);
    //    var_dump($listDorayaki);
    } 
    catch (Exception $e) 
    { 
        echo "<h2>Exception Error!</h2>"; 
        echo $e->getMessage(); 
    }

    header("Location: ../phpmailer/index.php");

?>
