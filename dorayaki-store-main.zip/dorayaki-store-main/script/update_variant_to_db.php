<?php
	//starting the session
	session_start();

	$username = $_COOKIE['username'];

	if(ISSET($_POST['submit'])){
		// Setting variables
		$var_id = $_POST['var_id'];
		$nama = $_POST['nama'];
		$deskripsi = $_POST['desc'];
		$harga = $_POST['harga'];
		$stok = $_POST['stok'];
		$gambar = $_FILES['gambar']['name'];
        $syntaxErr = "";

		// copy gambar ke dir img
        move_uploaded_file($_FILES['gambar']['tmp_name'], 'img/'.$gambar);

        $pdo = new PDO('sqlite:../db/db_member.sqlite3');

        $statement = $pdo->query("SELECT * FROM variant");

        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement = $pdo->query("SELECT * FROM variant where var_id == '$var_id'");

        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

		// Update Query
		$query = "REPLACE INTO `variant` (var_id, nama, deskripsi, harga, stok, terjual, gambar) VALUES(:var_id, :nama, :desc, :harga, :stok, 0, :gambar)";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(':var_id', $var_id);
		$stmt->bindParam(':nama', $nama);
		$stmt->bindParam(':desc', $deskripsi);
		$stmt->bindParam(':harga', $harga);
		$stmt->bindParam(':stok', $stok);
		$stmt->bindParam(':gambar', $gambar);

		$stok_awal = $rows[0]['stok'];
		$pengubahan = $stok - $stok_awal;
		date_default_timezone_set("Asia/Jakarta");
		$date = date("y-m-d H:i:s");
		if ($pengubahan != 0) {
			// Insertion query to stok db
			$query2 = "INSERT INTO `stok_history` (username, var_id, varian, stok_awal, stok_akhir, pengubahan, date) VALUES(:username, :var_id, :varian, :stok_awal, :stok_akhir, :pengubahan, :date)";
			$stmt2 = $pdo->prepare($query2);
			$stmt2->bindParam(':username', $username);
			$stmt2->bindParam(':var_id', $var_id);
			$stmt2->bindParam(':varian', $nama);
			$stmt2->bindParam(':stok_awal', $stok_awal);
			$stmt2->bindParam(':stok_akhir', $stok);
			$stmt2->bindParam(':pengubahan', $pengubahan);
			$stmt2->bindParam(':date', $date);
			$stmt2->execute();
		}

		// Check if the execution of query is success
        if(strlen($syntaxErr)>0) {
			$_SESSION['pesan'] = "Varian gagal diupdate";
            header('location: ../edit_variant.php?id='.$var_id);
        }
        else {
			if($stmt->execute()){
				//setting a 'success' session to save our insertion success message.
                $_SESSION['variant_updated'] = true;
				$_SESSION['pesan'] = "Varian $nama berhasil diupdate";

                //redirecting to the index.php 
                header('location: ../edit_variant.php?id='.$var_id);
            }
        }
	} else {
		//redirecting to error page 
		header('location: ../error_page.php');
	}
?> 
