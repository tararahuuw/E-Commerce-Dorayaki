<?php
    $pdo = new PDO('sqlite:db/db_member.sqlite3');
    // pagination
    // konfigurasi
    $jumlahDataPerHalaman = 10;
    if ($_POST["query"]) {
        $search_query = $_POST["query"];
        $jumlahData= $pdo->query("SELECT COUNT(*) as count FROM variant WHERE nama LIKE '%$search_query%'");
    } else {
        $search_query = '';
        $jumlahData= $pdo->query("SELECT COUNT(*) as count FROM variant");
    }
    $jumlahData = $jumlahData->fetchAll(PDO::FETCH_ASSOC);
    $jumlahHalaman = ceil((int)$jumlahData[0]["count"] / $jumlahDataPerHalaman);
    $halamanAktif = ( isset($_POST["page"]) ) ? $_POST["page"] : 1;
    $awalData = ( $jumlahDataPerHalaman * $halamanAktif ) - $jumlahDataPerHalaman;

    if ($_POST["query"]) {
        $variant= $pdo->query("SELECT * FROM variant WHERE nama LIKE '%$search_query%' ORDER BY terjual DESC LIMIT $awalData, $jumlahDataPerHalaman");
    } else {
        $variant= $pdo->query("SELECT * FROM variant ORDER BY terjual DESC LIMIT $awalData, $jumlahDataPerHalaman");
    }
    
    $variant = $variant->fetchAll(PDO::FETCH_ASSOC);

    $pagination = '';

    if( $halamanAktif > 1 ) :
        $pagination .= '<a href="javascript:load_data(`'. $search_query .'`,'. $halamanAktif - 1 .')">&laquo;</a>';
    endif;

    for( $i = 1; $i <= $jumlahHalaman; $i++ ) :
        if( $i == $halamanAktif ) :
            $pagination .= '<a href="javascript:load_data(`'. $search_query .'`,'. $i .')" class="halaman-aktif">'. $i .'</a>';
        else :
            $pagination .= '<a class="halaman-nonaktif" href="javascript:load_data(`'. $search_query .'`,'. $i .')">'. $i .'</a>';
        endif;
    endfor;

    if( $halamanAktif < $jumlahHalaman ) :
        $pagination .= '<a href="javascript:load_data(`'. $search_query .'`,'. $halamanAktif + 1 .')">&raquo;</a>';
    endif;

    $output = array(
		'data'				=>	$variant,
        'total_data'		=>	(int)$jumlahData[0]["count"],
        'pagination'        =>  $pagination
	);

    echo json_encode($output);
?>