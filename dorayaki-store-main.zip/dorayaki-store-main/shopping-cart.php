<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/cart.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="icon" href="src/images/logo-icon.ico" type="image/x-icon" />
    <title>Dorayaki Store</title>
  </head>
  <body>
    <?php include 'component/navbar.php'; ?>
      <div class="table-container">
        <table>
          <tr>
              <th></th>
              <th>NAMA</th>
              <th>QT.</th>
              <th>HARGA SATUAN</th>
              <th>TOTAL</th>
          </tr>
          <?php include 'component/cart-item.php'; ?>
          <?php include 'component/cart-item.php'; ?>
        </table>
      </div>

      <div class="total-container">
        <?php include 'component/cart-total.php'; ?>
      </div>
      
    <!-- <script src="src/script/index.js"></script> -->
  </body>
</html>
