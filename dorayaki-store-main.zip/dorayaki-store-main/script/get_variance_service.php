<?php
    $wsdl   = "http://localhost:9999/webservice/dorayaki?wsdl";
    $client = new SoapClient($wsdl, array('trace'=>1));  // The trace param will show you errors stack

    $request_param = array(
        "getStock" => array(
            "arg0"        => -1,
        ) 
    );
    
    try
    {
       $listDorayaki =  $client->__soapCall("getStock", $request_param)->return; // Alternative way to call soap method
       $listDorayaki = json_decode($listDorayaki, true);
       /* $listDorayaki2 =  $client->__soapCall("getStock", $request_param)->return; // Alternative way to call soap method
       $listDorayaki2 = json_decode($listDorayaki2, true);
       array_push($listDorayaki, $listDorayaki2[0]);*/
       #var_dump($listDorayaki); 
    } 
    catch (Exception $e) 
    { 
        echo "<h2>Exception Error!</h2>"; 
        echo $e->getMessage(); 
    }
?>