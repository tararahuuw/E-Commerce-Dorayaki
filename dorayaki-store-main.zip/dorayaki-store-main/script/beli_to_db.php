<?php
	//starting the session
	session_start();

	$username = $_COOKIE["username"];

	if(ISSET($_POST['submit'])){
		// Setting variables
        $quantity = $_POST['quantity'];
        $var_id = $_POST['var_id'];
        $syntaxErr = "";

        $pdo = new PDO('sqlite:../db/db_member.sqlite3');

     /*    $statement = $pdo->query("SELECT * FROM variant");

        $rows = $statement->fetchAll(PDO::FETCH_ASSOC); */
        $statement = $pdo->query("SELECT * FROM variant where var_id == '$var_id'");

        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

		$varian = $rows[0]['nama'];
		$stok_awal = $rows[0]['stok'];
		$pengubahan = abs($stok_awal - $quantity);
		$negquantity = $quantity * (-1);
		$terjual = $rows[0]['terjual'];
		$terjual_updated = $terjual + $quantity;
		date_default_timezone_set("Asia/Jakarta");
		$date = date("y-m-d H:i:s");

        $harga = $quantity * $rows[0]['harga'];

		// Update variant stok
		$query = "UPDATE `variant` SET stok=:stok WHERE var_id=:var_id";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(':var_id', $var_id);
		$stmt->bindParam(':stok', $pengubahan);

		// Update variant terjual
		$query3 = "UPDATE `variant` SET terjual=:terjual WHERE var_id=:var_id";
		$stmt3 = $pdo->prepare($query3);
		$stmt3->bindParam(':var_id', $var_id);
		$stmt3->bindParam(':terjual', $terjual_updated);

        // Insert query to pembelian
        $query1 = "INSERT INTO `pembelian` (username, var_id, varian, jumlah, harga, date) VALUES(:username, :var_id, :varian, :jumlah, :harga, :date)";
        $stmt1 = $pdo->prepare($query1);
		$stmt1->bindParam(':username', $username);
		$stmt1->bindParam(':var_id', $var_id);
		$stmt1->bindParam(':varian', $varian);
		$stmt1->bindParam(':jumlah', $quantity);
		$stmt1->bindParam(':harga', $harga);
		$stmt1->bindParam(':date', $date);

		// Insertion query to stok db
		$query2 = "INSERT INTO `stok_history` (username, var_id, varian, stok_awal, stok_akhir, pengubahan, date) VALUES(:username, :var_id, :varian, :stok_awal, :stok_akhir, :pengubahan, :date)";
		$stmt2 = $pdo->prepare($query2);
		$stmt2->bindParam(':username', $username);
		$stmt2->bindParam(':var_id', $var_id);
		$stmt2->bindParam(':varian', $varian);
		$stmt2->bindParam(':stok_awal', $stok_awal);
		$stmt2->bindParam(':stok_akhir', $pengubahan);
		$stmt2->bindParam(':pengubahan', $negquantity);
		$stmt2->bindParam(':date', $date);

		// Check if the execution of query is success
        if($pengubahan == 0 || strlen($syntaxErr)>0) {
			$_SESSION['pesan'] = "Varian gagal diupdate";
            header('location: ../beli_variant.php?id='.$var_id);
        }
        else {
			if($stmt->execute() ){
                $stmt1->execute();
                $stmt2->execute();
				$stmt3->execute();
				
				//setting a 'success' session to save our insertion success message.
                $_SESSION['variant_updated'] = true;
				$_SESSION['pesan'] = "Anda berhasil membeli $varian!";

                //redirecting to the index.php 
                header('location: ../detailproduct.php?id='.$var_id);
            }
        } 
	} else {
		//redirecting to error page 
		header('location: ../error_page.php');
	}
?> 
