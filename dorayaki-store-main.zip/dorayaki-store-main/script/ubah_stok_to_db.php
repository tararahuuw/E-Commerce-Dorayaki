<?php

	// starting the session
	session_start();

	$username = $_COOKIE["username"];

	$wsdl   = "http://localhost:9999/webservice/dorayaki?wsdl";
	$client = new SoapClient($wsdl, array('trace'=>1));  // The trace param will show you errors stack

	try
	{
		$listDorayaki = $_SESSION['listDorayaki'];
		
	    $pdo = new PDO('sqlite:../db/db_member.sqlite3');
			
		$statement = $pdo->query("SELECT * FROM variant");

		for ($i=0; $i < count($listDorayaki); $i++) {
			$syntaxErr = "";

			$name = $listDorayaki[$i]['name'];

			$rows = $statement->fetchAll(PDO::FETCH_ASSOC);
			$statement = $pdo->query("SELECT * FROM variant where nama == '$name'");

			$rows = $statement->fetchAll(PDO::FETCH_ASSOC);

			$var_id = $rows[0]['var_id'];
			$varian = $rows[0]['nama'];
			$stok_awal = $rows[0]['stok'];
			$pengubahan	= $listDorayaki[$i]['quantity'];
			$stok_akhir = $stok_awal + $pengubahan;
			date_default_timezone_set("Asia/Jakarta");
			$date = date("y-m-d H:i:s");

			// Update Query
			$query = "UPDATE `variant` SET stok=:stok WHERE var_id=:var_id";
			$stmt = $pdo->prepare($query);
			$stmt->bindParam(':var_id', $var_id);
			$stmt->bindParam(':stok', $stok_akhir);

			// Insertion query to stok db
			$query2 = "INSERT INTO `stok_history` (username, var_id, varian, stok_awal, stok_akhir, pengubahan, date) VALUES(:username, :var_id, :varian, :stok_awal, :stok_akhir, :pengubahan, :date)";
			$stmt2 = $pdo->prepare($query2);
			$stmt2->bindParam(':username', $username);
			$stmt2->bindParam(':var_id', $var_id);
			$stmt2->bindParam(':varian', $varian);
			$stmt2->bindParam(':stok_awal', $stok_awal);
			$stmt2->bindParam(':stok_akhir', $stok_akhir);
			$stmt2->bindParam(':pengubahan', $pengubahan);
			$stmt2->bindParam(':date', $date);

			// Check if the execution of query is success
			if($pengubahan == 0 || strlen($syntaxErr)>0) {
				$_SESSION['pesan'] = "Varian gagal diupdate";
				header('location: ../beli_variant.php?id='.$var_id);
			}
			else {
				if($stmt->execute() && $stmt2->execute()){
					$request_param = array(
						"setAcceptedStore" => array(
							"arg0"    => $listDorayaki[$i]['id']   
						) 
					);
					
					$client->__soapCall("setAcceptedStore", $request_param); // isGetStore = True

					//setting a 'success' session to save our insertion success message.
					$_SESSION['variant_updated'] = true;
					$_SESSION['pesan'] = "Stok varian $varian berhasil diupdate";

					//redirecting to the index.php 
					header('location: ../home.php');
				}
			}
		}

	} 
	catch (Exception $e) 
	{ 
		echo "<h2>Exception Error!</h2>"; 
		$_SESSION['error'] = $e->getMessage();
		header("Location: ../error_page.php");
	}
?> 
