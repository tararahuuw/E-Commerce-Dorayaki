<!DOCTYPE html>
<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }

    if (!isset($_SESSION["login"])) {
        header("Location: logout.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    if ($is_admin === "Customer") {
        $_SESSION['error'] = 403;
        header('location: error_page.php');
    }
    $username = $_COOKIE["username"];
?>
<html lang="en">
	<head>
        <title>Dorayaki Store</title>
        <link rel="icon" href="img/doraemon.png" type="image/icon type">
        <link rel="stylesheet" type="text/css" href="css/dashboard.css">
        <link rel="stylesheet" type="text/css" href="css/variant.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
<body>
    <?php include 'script/get_variance_service.php'; ?>
    <!-- component navbar -->
    <?php include 'component/navbar.php'; ?>
    <div class="main">
        <div class="container">

            <!-- Open modal -->
            <div class="pop-up">
            <?php
            if (isset($_SESSION['variant_added']) && $_SESSION['variant_added'] == true) { ?>
                <h2 id="pesan" class="sukses"> <?php echo $_SESSION['pesan'] ?> </h2>
                <?php
                unset($_SESSION['variant_added']);
                unset($_SESSION['pesan']);
            } else if (isset($_SESSION['pesan'])){ ?>
                <h2 id="pesan" class="gagal"> <?php echo $_SESSION['pesan'] ?> </h2>
                <?php 
                unset($_SESSION['pesan']);
            } ?>
            </div>

            <!-- Add variant card -->
            <div class="card-variant">
                <h2>Tambahkan Varian Baru Dorayaki</h2><br>

                <form id="submit-form" method="POST" enctype="multipart/form-data" action="script/add_variant_to_db.php">

                    <div class="container-display">
                        <img class="display" id="display" src="img/dorayaki.jpg"/>
                    </div>

                    <label class="file-upload">
                    <input type="file" name="gambar" accept="image/*" onchange="loadFile(event)" required/>
                        Pilih Foto
                    </label><br>
                    <div class="m-05 flex-container column">
                    <select class="input" name="nama">
                        <?php for ($i=0; $i < count($listDorayaki); $i++) {?>    
                            <option value="<?php echo $listDorayaki[$i]["recipeName"]?>">
                                <?php echo $listDorayaki[$i]["recipeName"]?>
                            </option>
                        <?php } ?> 
                    </select>
                    </div>
                    <div class="form">
                    <input type="text" name="harga" placeholder="Harga" class="input" required/><br>
                    <input type="number" name="stok" placeholder="Stok" class="input" required/><br>
                    <textarea type="textarea" name="desc" placeholder="Detail Produk" class="input-textarea" required></textarea><br>
                    </div>
                    
                    <input type="submit" name="submit" value="Tambahkan" class="submit"/>

                </form>
            </div>
        </div>
    </div>
    <script src="js/navbar.js"></script>
    <script>
        // Display gambar
        var loadFile = function(event) {
            var image = document.getElementById('display');
            image.src = URL.createObjectURL(event.target.files[0]);
        };
        setTimeout(function(){
            document.getElementById('pesan').className += ' hilang';
        }, 2000);
    </script>
</body>
</html>