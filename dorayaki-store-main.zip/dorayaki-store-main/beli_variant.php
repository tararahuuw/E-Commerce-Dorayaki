<!DOCTYPE html>

<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }

    if (!isset($_SESSION["login"])) {
        header("Location: logout.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    $username = $_COOKIE["username"];

    $pdo = new PDO('sqlite:db/db_member.sqlite3');
    $index = (int)$_GET["id"];
    $product = $pdo->query("SELECT * FROM variant where var_id == $index");
    $product = $product->fetchAll(PDO::FETCH_ASSOC);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="css/variant.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <title><?php echo($product[0]["nama"])  ?></title>
    <link rel="icon" href="img/<?php echo($product[0]['gambar'])  ?>" type="image/icon type">
</head>
<body>

    <!-- Component Navbar -->
    <?php include 'component/navbar.php'; ?>
    <div id="popup"></div>

    <!-- Card product -->
    <div class = "container-productdetail">
        <div class ="card">
            <img src="img/<?php echo($product[0]['gambar'])  ?>"/>
            <p class="judul-card"><?php echo($product[0]["nama"])  ?></p>
            <p class="deskripsi-card"><?php echo($product[0]["deskripsi"])  ?></p>
            <p class="terjual-card">Jumlah terjual : <?php echo($product[0]["terjual"])  ?></p>
            <?php
            if ($is_admin === "Customer") { ?>
                <p class="terjual-card">Stok : <?php echo($product[0]['stok'])  ?></p><br>
                <div class="flex-container row justify-between">
                    <button id="min-quantity" class="btn-primary">-</button>
                    <div><span id="quantity" class="judul-card">0</span></div>
                    <button id="add-quantity" class="btn-primary">+</button>
                </div>
                <div class="flex-container column justify-between item-start">
                    <h3>Harga : Rp <?php echo($product[0]['harga']) ?></h3>
                    <h3>Total</h3>
                    <p id="total-price" class="judul-card">Rp0</p>
                </div>
                <form id="submit-form" method="POST" enctype="multipart/form-data" action="script/beli_to_db.php">
                    <input type="hidden" name="quantity" value="0" class="quantity"/>
                    <input type="hidden" name="var_id" value="<?php echo $product[0]['var_id'] ?>"/>
                    <input type="submit" name="submit" value="Beli" class="button-card"/>
                </form>
            <?php
            } else { ?>
            <form id="submit-form" method="POST" enctype="multipart/form-data" action="script/ubah_stok_to_db.php">
                <div class="form flex-container column">
                    <div class="m-05">
                    <h5>Nama Bahan Baku: </h5>
                    <select class="input" name="bahan_baku[]">
                        <option> Tepung Terigung</option>
                        <option> Ayam</option>
                    </select>
                    </div>
                    <div class="m-05">
                        <input type="hidden" name="var_id" value="<?php echo $product[0]['var_id'] ?>"/>
                        <h5>Kuantitas: </h5>
                        <input type="number" name="stok" placeholder="Stok" class="input" value="<?php echo $product[0]['stok'] ?>"/><br>
                    </div>
                </div>
                <input type="submit" name="submit" value="Ubah" class="submit"/>
            </form>
            <?php
            } ?>
        </div>
    </div>
    <div id="max-stock" style="display: none"><?php echo($product[0]['stok']) ?></div>
    <div id="price-stock" style="display: none"><?php echo($product[0]['harga']) ?></div>
    <script src="js/navbar.js"></script>
    <script src="js/pembelian.js"></script>
  <!--   <script>
        setTimeout(function(){
            document.getElementById('pesan').className += ' hilang';
        }, 2000);
        </script> -->
</body>
</html>
