<!DOCTYPE html>
<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }

    if (!isset($_SESSION["login"])) {
        header("Location: logout.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    $username = $_COOKIE["username"];
    $pdo = new PDO('sqlite:db/db_member.sqlite3');

    // pagination
    // konfigurasi
    $jumlahDataPerHalaman = 10;
    $jumlahData= $pdo->query("SELECT COUNT(*) as count FROM variant");
    $jumlahData = $jumlahData->fetchAll(PDO::FETCH_ASSOC);
    $jumlahHalaman = ceil((int)$jumlahData[0]["count"] / $jumlahDataPerHalaman);
    $halamanAktif = ( isset($_GET["halaman"]) ) ? $_GET["halaman"] : 1;
    $awalData = ( $jumlahDataPerHalaman * $halamanAktif ) - $jumlahDataPerHalaman;

    $variant= $pdo->query("SELECT * FROM variant ORDER BY terjual DESC LIMIT $awalData, $jumlahDataPerHalaman");
    $variant = $variant->fetchAll(PDO::FETCH_ASSOC);
    
    // var_dump($jumlahHalaman);
?>
<html lang="en">
	<head>
        <title>Dorayaki Store</title>
        <link rel="stylesheet" type="text/css" href="css/dashboard.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
<body>
    <?php include 'component/navbar.php'; ?>
      <div class="content">
        <?php if (isset($_SESSION['error'])) { ?>
            <h1>ERROR</h1>
            <?php if ($_SESSION['error'] === 403) { ?>
                <h1>403 Forbidden</h1>
                <h2>The server has refused to fulfill your request.</h2>
            <?php
            } if ($_SESSION['error'] === 404) { ?>
                <h1>404 Not Found</h1>
                <h2>The server could not find what was requested.</h2>
            <?php
            }
        }
        ?>
      </div>
        
    <script src="js/navbar.js"></script>
</body>
</html>