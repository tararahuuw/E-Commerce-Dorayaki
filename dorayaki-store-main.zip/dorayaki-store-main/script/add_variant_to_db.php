<?php
	//starting the session
	session_start();

	if(ISSET($_POST['submit'])){
		// Setting variables
		$nama = $_POST['nama'];
		$deskripsi = $_POST['desc'];
		$harga = $_POST['harga'];
		$stok = $_POST['stok'];
		$gambar = $_FILES['gambar']['name'];
        $syntaxErr = "";

		// copy gambar ke dir img
        move_uploaded_file($_FILES['gambar']['tmp_name'], 'img/'.$gambar);

        $pdo = new PDO('sqlite:../db/db_member.sqlite3');

        $statement = $pdo->query("SELECT * FROM variant");

        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement = $pdo->query("SELECT * FROM variant where nama == '$nama'");

        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

		// Insertion Query
		$query = "INSERT INTO `variant` (nama, deskripsi, harga, stok, terjual, gambar) VALUES(:nama, :desc, :harga, :stok, 0, :gambar)";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(':nama', $nama);
		$stmt->bindParam(':desc', $deskripsi);
		$stmt->bindParam(':harga', $harga);
		$stmt->bindParam(':stok', $stok);
		$stmt->bindParam(':gambar', $gambar);

		// Check if the execution of query is success
        if($rows || strlen($syntaxErr)>0) {
			$_SESSION['pesan'] = "Varian gagal ditambahkan";
            header('location: ../add_variant.php');
        }
        else {
			if($stmt->execute()){
				//setting a 'success' session to save our insertion success message.
                $_SESSION['variant_added'] = true;
				$_SESSION['pesan'] = "Varian $nama berhasil ditambahkan";

                //redirecting to the index.php 
                header('location: ../add_variant.php');
            }
        }
	} else {
		//redirecting to error page 
		header('location: ../error_page.php');
	}
?> 