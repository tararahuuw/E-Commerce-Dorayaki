<?php

	// selecting database query for ajax
    $pdo = new PDO('sqlite:db/db_member.sqlite3');
    $statement = $pdo->query("SELECT * FROM member");
    $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
	$usernameinput = $_GET['username'];
	$statement = $pdo->query("SELECT * FROM member where username == '$usernameinput'");
    $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

	// Component will change
	if ($rows) {?>
		<hr id="penanda" class="hr_red"/>
		<p><i>Username must be unique<i></p>
		<div class="input-div one">
			<div class="i">
				<i class="fas fa-envelope"></i>
			</div>
			<div class="div">
				<input type="text" name="email" class="form-control" required="required" class="input" placeholder = "user@gmail.com">
			</div>
		</div>
		<hr/>
		
		<div class="input-div one">
			<div class="i"> 
				<i class="fas fa-lock"></i>
			</div>
			<div class="div">
				<input type="password" name="password" class="form-control" required="required" placeholder = "Password">
			</div>
		</div>
		<hr/>
		<button class="btn btn-block" name="register"><span class="glyphicon glyphicon-save"></span> Register</button>
		<p>Have an account?<a href="index.php">‏‏‎ ‎‏‎Register</a></p>
	<?php
	}
	else {?>
		<hr id="penanda" class="hr_green"/>
		<div class="input-div one">
			<div class="i">
				<i class="fas fa-envelope"></i>
			</div>
			<div class="div">
				<input type="text" name="email" class="form-control" required="required" class="input" placeholder = "user@gmail.com">
			</div>
		</div>
		<hr/>
		<div class="input-div one">
			<div class="i"> 
				<i class="fas fa-lock"></i>
			</div>
			<div class="div">
				<input type="password" name="password" class="form-control" required="required" placeholder = "Password">
			</div>
		</div>
		<hr/>
		<button class="btn btn-block" name="register"><span class="glyphicon glyphicon-save"></span> Register</button>
		<p>Have an account?<a href="index.php">‏‏‎ Login</a></p>
	<?php }
?>