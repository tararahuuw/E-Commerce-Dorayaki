<?php
	//starting the session
	session_start();
 
	//including the database connection
	require_once 'conn.php';
 
	if(ISSET($_POST['register'])){
		// Setting variables
		$username = $_POST['username'];
		$password = $_POST['password'];
		$email = $_POST['email'];
        $syntaxErr = "";

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $pdo = new PDO('sqlite:db/db_member.sqlite3');

        $statement = $pdo->query("SELECT * FROM member where username == '$username'");
    
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
 
		// Insertion Query
		$query = "INSERT INTO `member` (email, username, password) VALUES(:email, :username, :password)";
		$stmt = $conn->prepare($query);
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':username', $username);
		$stmt->bindParam(':password', $hashed_password);

        if (!preg_match("/^[a-z0-9_]+$/i",$username)) {
            $syntaxErr = "Only letters and white space allowed";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $syntaxErr = "Invalid email format";
        }
 
		// Check if the execution of query is success
        if($rows || strlen($syntaxErr)>0) {
            header('location: register.php');
        }
        else {
            if($stmt->execute()){
                //setting a 'success' session to save our insertion success message.
                $_SESSION['success'] = "Successfully created an account";

                $statement = $pdo->query("SELECT * FROM member where username == '$username'");
                $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

                setcookie('id', $rows[0]['mem_id'], time()+3600);
                setcookie('username', $rows[0]['username'], time()+3600);
                setcookie('is_admin', $rows[0]['is_admin'], time()+3600);
     
                //redirecting to the index.php 
                header('location: home.php');
            }
        }
	}
?>