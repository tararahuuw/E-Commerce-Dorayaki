let quantity = 0;
let reduceQuantity = document.getElementById('min-quantity');
let addQuantity = document.getElementById('add-quantity');
let buy = document.getElementsByName('submit');
const maxStock = document.getElementById('max-stock').innerHTML;
const price = document.getElementById('price-stock').innerHTML;

reduceQuantity.onclick = () => {
  if (quantity > 0) {
    quantity = quantity - 1;
    document.getElementById('quantity').innerText = quantity;
    document.getElementById('total-price').innerText =
      'Rp' + new Intl.NumberFormat('de-DE').format(quantity * price);
  }
  console.log('red: ' + quantity);
  document.getElementsByTagName('input')[1].value = quantity;
};

addQuantity.onclick = () => {
  if (quantity < maxStock) {
    quantity = quantity + 1;
    document.getElementById('quantity').innerText = quantity;
    document.getElementById('total-price').innerText =
      'Rp' + new Intl.NumberFormat('de-DE').format(quantity * price);
  }
  console.log('add: ' + quantity);
  document.getElementsByTagName('input')[1].value = quantity;
};
