<!DOCTYPE html>
<?php
    session_start();

	// cek cookie
	if( isset($_COOKIE['id'])) {
		$_SESSION['login'] = true;
	}

    if (isset($_SESSION["login"])) {
		header("Location: home.php");
		exit; 
    }

?>
<html lang="en">
	<head>
        <title>Dorayaki Store</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
<body>
    <div>
        <img class="wave" src="img/wave.png">
		<!-- Link for redirecting to Login Page -->
        <div class="container">
            <div class="img">
                <img src="img/doraemon.png">
            </div>
            <!-- <a href="login.php">Already a member? Log in here...</a> -->
            <div class="login-content">
			<!-- Login Form Starts -->
                    <form method="POST" action="login_query.php" class="formcontainer">
                        <img src="img/avatar.svg">
                        <h2 class="title">Login</h2>
                        <div class="input-div one">
                            <div class="i">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="div">
                                <input type="text" name="username" class="form-control" required="required" class="input" placeholder = "Username">
                            </div>
                        </div>
                        <hr/>
                        <div class="input-div one">
                            <div class="i"> 
                                <i class="fas fa-lock"></i>
                            </div>
                            <div class="div">
                                <input type="password" name="password" class="form-control" required="required" placeholder = "Password">
                            </div>
                        </div>
                        <hr/>
                        <?php
                            //checking if the session 'error' is set. Erro session is the message if the 'Username' and 'Password' is not valid.
                            if(ISSET($_SESSION['error'])){
                        ?>
                        <!-- Display Login Error message -->
                            <div class="alert alert-danger"><?php echo $_SESSION['error']?></div>
                        <?php
                            //Unsetting the 'error' session after displaying the message. 
                            unset($_SESSION['error']);
                            }
                        ?>
                        <button class="btn btn-block" name="login"><span class="glyphicon glyphicon-log-in"></span> Login</button>
                        <p>Don't have an account?<a href="register.php">‏‏‎ ‎‏‎Register</a></p>
                    </form>
                </div>
                
			<!-- Login Form Ends -->
		</div>
	</div>
</body>
</html>