<!DOCTYPE html>
<?php
    session_start();

    if (isset($_SESSION["login"])) {
        header("Location: home.php");
    }
?>
<html lang="en">
	<head>
        <title>Dorayaki Store</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
<body>
	<div>
        <img class="wave" src="img/wave.png">
		<!-- Link for redirecting to Login Page -->
        <div class="container">
            <div class="img">
                <img src="img/doraemon.png">
            </div>
            <!-- <a href="login.php">Already a member? Log in here...</a> -->
            <div class="login-content">
                <form method="POST" action="save_member.php">
                    <img src="img/avatar.svg">
                    <h2 class="title">Register</h2>
                    <div class="input-div one">
                        <div class="i">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="div">
                            <input type="text" name="username" class="form-control" required="required" class="input" placeholder = "Username" id="username">
                        </div>
                    </div>
                    <div id="penanda">
                        <hr/>
                    <div>
                    <div class="input-div one">
                        <div class="i">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="div">
                            <input type="text" name="email" class="form-control" required="required" class="input" placeholder = "user@gmail.com">
                        </div>
                    </div>
                    <hr/>
                    <div class="input-div one">
                        <div class="i"> 
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="div">
                            <input type="password" name="password" class="form-control" required="required" placeholder = "Password">
                        </div>
                    </div>
                    <hr/>
                    <button class="btn btn-block" name="register"><span class="glyphicon glyphicon-save"></span> Register</button>
                    <p>Have an account?<a href="index.php">‏‏‎ Login</a></p>
                </form>	
                
            </div>
        </div>
			
			<!-- Registration Form end -->
		</div>
	</div>

<script>
    // ambil elemen2 yang dibutuhkan
    var username = document.getElementById('username');
    var container = document.getElementById('penanda');

    // tambahkan event ketika keyword ditulis
    username.addEventListener('keyup', function() {

        // buat object ajax
        var xhr = new XMLHttpRequest();

        // cek kesiapan ajax
        xhr.onreadystatechange = function() {
            if( xhr.readyState == 4 && xhr.status == 200 ) {
                container.innerHTML = xhr.responseText;
                // container.style.borderColor = "salmon"
            }
        }

        // eksekusi ajax
        xhr.open('GET', 'ajaxregister.php?username='+username.value, true);
        xhr.send();

    });
</script>
</body>
</html>