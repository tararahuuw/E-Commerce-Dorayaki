<nav>
    <div class="menu-icon">
        <span class="fas fa-bars"></span>
    </div>
    <div class="logo">
        <a href="home.php">DoraStore</a>
    </div>
    <?php 
        if ($is_admin === "Customer") { ?>
        <div class="nav-items">
            <li><a href="home.php">Home</a></li>
            <li><a href="history.php">History</a></li>
            <li><a href="logout.php">Logout</a></li>
        </div>  
        <?php } 
        else { ?>
        <div class="nav-items">
            <li><a href="home.php">Home</a></li>
            <li><a href="add_variant.php">Add Variance</a></li>
            <li><a href="update_variant.php">Update Variance</a></li>
            <li><a href="history.php">History</a></li>
            <li><a href="logout.php">Logout</a></li>
        </div>  
        <?php } ?>
    <div class="search-icon">
        <span class="fas fa-search"></span>
    </div>
    <div class="cancel-icon">
        <span class="fas fa-times"></span>
    </div>
    <form action="search-result.php" method="POST">
        <input type="text" name="search-query" class="search-data" placeholder="Search" onkeyup="load_data(this.value);">
        <button type="submit" class="fas fa-search"></button>
    </form>
    <div class="profile">
        <div class = "vertical"></div>
        <div>
            <p class="name"><?php echo($username)?></p>
            <p class="role"><?php echo($is_admin)?></p>
        </div>

    </div>
</nav>
<script src="js/pagination.js"></script>