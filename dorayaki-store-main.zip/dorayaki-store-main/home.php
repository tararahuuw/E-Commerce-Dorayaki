<!DOCTYPE html>
<?php
    session_start();
    // cek cookies
    if (!isset($_COOKIE["id"])){
        unset($_SESSION["login"]);
    }
    if (!isset($_SESSION["login"])) {
        header("Location: index.php");
    }

    $is_admin = $_COOKIE["is_admin"];
    $username = $_COOKIE["username"];
    $pdo = new PDO('sqlite:db/db_member.sqlite3');

    // update accepted stock
    $wsdl   = "http://localhost:9999/webservice/dorayaki?wsdl";
	$client = new SoapClient($wsdl, array('trace'=>1));  // The trace param will show you errors stack
    $request_param = array(
        "getAcceptedRequests" => array(
            "arg0"    => -1,      
        ) 
    );
    
    $listDorayaki =  $client->__soapCall("getAcceptedRequests", $request_param)->return; // Alternative way to call soap method
    $listDorayaki = json_decode($listDorayaki, true);
    if (count($listDorayaki) > 0) {
        $_SESSION["listDorayaki"] = $listDorayaki;
        header("Location: script/ubah_stok_to_db.php");
    }

    // pagination
    // konfigurasi
    $jumlahDataPerHalaman = 10;
    $jumlahData= $pdo->query("SELECT COUNT(*) as count FROM variant");
    $jumlahData = $jumlahData->fetchAll(PDO::FETCH_ASSOC);
    $jumlahHalaman = ceil((int)$jumlahData[0]["count"] / $jumlahDataPerHalaman);
    $halamanAktif = ( isset($_POST["page"]) ) ? $_POST["page"] : 1;
    $awalData = ( $jumlahDataPerHalaman * $halamanAktif ) - $jumlahDataPerHalaman;

    $variant= $pdo->query("SELECT * FROM variant ORDER BY terjual DESC LIMIT $awalData, $jumlahDataPerHalaman");
    $variant = $variant->fetchAll(PDO::FETCH_ASSOC);

    $output = array(
		'data'				=>	$variant,
        'total_data'		=>	(int)$jumlahData[0]["count"],
        'data_per_page'     =>  $jumlahDataPerHalaman,
        'active_page'       =>  $halamanAktif,
        'begin'             =>  $awalData
	);
?>

<html lang="en">
	<head>
        <title>Dorayaki Store</title>
        <link rel="stylesheet" type="text/css" href="css/dashboard.css">
        <link rel="stylesheet" type="text/css" href="css/variant.css">
        <link rel="stylesheet" type="text/css" href="css/search.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/a81368914c.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
<body>
    <?php include 'component/navbar.php'; ?>   
        <div id="post_data" class = "container-content">
            <?php
            if (isset($_SESSION['variant_deleted']) && $_SESSION['variant_deleted'] == true) { ?>
                <div id="popup" class="popup">
                    <h2 id="pesan" class="pesan"> <?php echo $_SESSION['pesan'] ?> </h2>
                </div>
                <?php
                unset($_SESSION['variant_deleted']);
                unset($_SESSION['pesan']);
            }?>
        </div>

        <div id="pagination" class = "pagination">
        </div>
    <script src="js/navbar.js"></script>
    <script src="js/pagination.js"></script>
    <script>
        // Pagination
        load_data();
        // Timeout for popup
        setTimeout(function(){
            document.getElementById('popup').className += ' hilang';
        }, 3000);
    </script>
</body>
</html>